import { prisma } from "@/lib/prisma"
import { hashPassword, signToken, isOwner } from "@/lib/auth"
import { NextRequest } from "next/server"

export async function POST(req: NextRequest){
  const {email,password,name} = await req.json()
  if(!email || !password || password.length<6) return Response.json({error:"Email and password min 6 chars required"},{status:400})
  
  // Gmail one-time check: normalize email (remove dots for gmail, lower)
  const normalized = email.toLowerCase().trim()
  // Prevent multiple free accounts: check if user exists
  const existing = await prisma.user.findUnique({where:{email:normalized}})
  if(existing) return Response.json({error:"Account already exists with this Gmail. Free is one-time only per Gmail. Please login or use different Gmail. If free credits exhausted (3/3), upgrade to paid plan."},{status:400})

  const hash = await hashPassword(password)
  const user = await prisma.user.create({ 
    data:{ 
      email: normalized, 
      name: name||email.split('@')[0], 
      password_hash: hash, 
      plan:"free", 
      status:"active", 
      is_owner:isOwner(email),
      current_period_end: new Date(Date.now()+365*24*60*60*1000) // free never expires by time, only by usage
    } 
  })
  const token = signToken({id:user.id,email:user.email})
  return Response.json({ user:{id:user.id,email:user.email,name:user.name,plan:user.plan,status:user.status,current_period_end:user.current_period_end,is_owner:user.is_owner,usage_count:user.usage_count}, token })
}