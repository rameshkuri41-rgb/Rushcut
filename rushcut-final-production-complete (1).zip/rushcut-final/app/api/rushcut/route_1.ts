import { NextRequest } from "next/server"
import { prisma } from "@/lib/prisma"
import { verifyToken, canGenerate, isSubscriptionActive, isOwner } from "@/lib/auth"

export async function POST(req: NextRequest){
  const auth = req.headers.get("authorization") || ""
  const token = auth.replace("Bearer ","")
  const payload = verifyToken(token)
  if(!payload) return Response.json({error:"Unauthorized - login required", fix:"Login again at /login"},{status:401})
  
  const user = await prisma.user.findUnique({where:{email:payload.email}})
  if(!user) return Response.json({error:"User not found"},{status:404})

  const { topic, n_scenes, mode, resolution } = await req.json()
  const estMin = (n_scenes * (mode==='sleep'?75:55)) / (mode==='sleep'?110:150)

  // Check canGenerate with free one-time logic + owner unlimited
  const check = canGenerate(user, n_scenes, estMin, resolution||"720p")
  if(!check.allowed){
    return Response.json({ 
      error: check.reason, 
      message: (check as any).message, 
      expired: (check as any).reason==="subscription_expired",
      free_exhausted: (check as any).reason==="free_credits_exhausted",
      user: { email:user.email, plan:user.plan, status:user.status, usage_count:user.usage_count, current_period_end:user.current_period_end, active: isSubscriptionActive(user), is_owner: isOwner(user.email) },
      fix: (check as any).reason==="free_credits_exhausted" ? "Upgrade at /billing - Free is Gmail one-time only (3 videos)" : (check as any).reason==="subscription_expired" ? "Renew at /billing" : "Upgrade plan",
      owner_debug: isOwner(user.email) ? "OWNER BYPASS ACTIVE - should never see this error. If you see this as owner, OWNER_EMAIL env mismatch." : undefined
    }, {status:403})
  }

  // Owner unlimited debug log
  if(isOwner(user.email)){
    console.log(`[OWNER UNLIMITED] ${user.email} generating ${n_scenes} scenes ${resolution} ${mode} - bypassing all limits`)
  }

  const engine = process.env.ENGINE_URL || "http://localhost:8000"
  try {
    const r = await fetch(`${engine}/jobs`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({topic,n_scenes,mode,resolution})})
    if(!r.ok){
      const err = await r.text()
      return Response.json({error:"Engine error", detail:err, fix:"Check Fly.io logs: fly logs --app rushcut-engine-4k, ensure ENGINE_URL env is set, and engine is running"}, {status:500})
    }
    const data = await r.json()
    await prisma.user.update({ where:{id:user.id}, data:{ usage_count: {increment:1} } })
    await prisma.video.create({ data:{ user_id:user.id, job_id:data.job_id, topic, mode, n_scenes, resolution:resolution||"720p", duration_sec: estMin*60, status:"processing" } })
    return Response.json({...data, owner_bypass: isOwner(user.email)})
  } catch(e:any){
    return Response.json({ 
      error:"Engine not reachable - video not generating", 
      detail:e.message, 
      fix:"1. Check ENGINE_URL in Vercel env (should be https://your-engine.fly.dev) 2. fly status --app rushcut-engine-4k 3. fly logs 4. Ensure engine has ffmpeg, edge-tts installed. For local test, set ENGINE_URL=http://localhost:8000 and run engine locally: cd engine && uvicorn server:app --port 8000",
      owner_debug: isOwner(user.email) ? "Owner bypass is active, but engine is down - fix engine URL" : undefined
    }, {status:500})
  }
}