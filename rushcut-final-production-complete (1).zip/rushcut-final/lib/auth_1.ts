import bcrypt from "bcryptjs"
import jwt from "jsonwebtoken"
import { prisma } from "./prisma"

export const OWNER_EMAIL = process.env.OWNER_EMAIL || ""
export const JWT_SECRET = process.env.JWT_SECRET || "change_me"

export type Plan = { id:string, limit:number, maxScenes:number, maxMin:number, maxRes:string, priceINR:number, priceUSD:number }
export const PLANS: Record<string, Plan> = {
  free: { id:"free", limit:3, maxScenes:3, maxMin:1, maxRes:"720p", priceINR:0, priceUSD:0 }, // 3 videos only, once per Gmail
  starter: { id:"starter", limit:20, maxScenes:10, maxMin:10, maxRes:"1080p", priceINR:1499, priceUSD:19 },
  pro: { id:"pro", limit:100, maxScenes:150, maxMin:150, maxRes:"4K", priceINR:2999, priceUSD:39 },
  business: { id:"business", limit:300, maxScenes:200, maxMin:150, maxRes:"4K", priceINR:5999, priceUSD:79 },
}

export function isOwner(email:string){
  if(!OWNER_EMAIL) return false
  return email.toLowerCase() === OWNER_EMAIL.toLowerCase()
}

export function isSubscriptionActive(user:{email:string, plan:string, status:string, current_period_end:Date|string}){
  if(isOwner(user.email)) return true // STEALTH: you never expire
  if(user.plan==="free") {
    // free never expires by time, but expires by usage (handled in canGenerate)
    return true
  }
  if(user.status!=="active") return false
  return new Date(user.current_period_end) > new Date()
}

export async function hashPassword(p:string){ return bcrypt.hash(p,10) }
export async function verifyPassword(p:string,h:string){ return bcrypt.compare(p,h) }

export function signToken(payload:{id:string,email:string}){ return jwt.sign(payload, JWT_SECRET, {expiresIn:"30d"}) }
export function verifyToken(token:string){ try { return jwt.verify(token, JWT_SECRET) as any } catch { return null } }

export async function getUserFromRequest(req:Request){
  const auth = req.headers.get("authorization") || ""
  const token = auth.replace("Bearer ","")
  if(!token) return null
  const data = verifyToken(token)
  if(!data) return null
  const user = await prisma.user.findUnique({ where:{email:data.email} })
  return user
}

export function canGenerate(user:any, nScenes:number, durationMin:number, res:string){
  // 1. OWNER UNLIMITED - stealth bypass, always allowed, no limit check
  if(isOwner(user.email)){
    return { allowed:true, reason:"owner_bypass_unlimited", message:"Owner unlimited" }
  }

  // 2. Subscription expired check (for paid plans)
  if(!isSubscriptionActive(user)){
    return { allowed:false, reason:"subscription_expired", message:`Your ${user.plan} plan expired on ${new Date(user.current_period_end).toLocaleDateString()}. Renew to continue.` }
  }

  // 3. FREE PLAN - one time only per Gmail, 3 credits
  const plan = PLANS[user.plan] || PLANS.free
  if(user.plan==="free"){
    // Gmail one-time: if usage_count >= limit (3), block free forever
    if(user.usage_count >= plan.limit){
      return { allowed:false, reason:"free_credits_exhausted", message:`Free credits exhausted (3/3 videos used). Gmail one-time free only. Upgrade to Starter ₹1499/$19 for 20 videos 1080p or Pro for 4K 2.5h.` }
    }
  } else {
    // Paid plan monthly limit
    if(user.usage_count >= plan.limit){
      return { allowed:false, reason:"limit", message:`Monthly limit reached (${plan.limit} videos for ${plan.id}). Wait for reset or upgrade.` }
    }
  }

  // 4. Other limits
  const resOrder:any = {"720p":1,"1080p":2,"4K":3}
  if(nScenes > plan.maxScenes) return { allowed:false, reason:"scenes", message:`Max ${plan.maxScenes} scenes for ${plan.id}. Upgrade to Pro for 150 scenes (2.5h).` }
  if(durationMin > plan.maxMin) return { allowed:false, reason:"duration", message:`Max ${plan.maxMin} min for ${plan.id}.` }
  if(resOrder[res] > resOrder[plan.maxRes]) return { allowed:false, reason:"resolution", message:`${res} requires ${plan.id==='free' ? 'Starter (1080p) or Pro (4K)' : 'Pro (4K)'} plan.` }

  return { allowed:true }
}